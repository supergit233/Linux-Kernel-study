---
name: kernel-driver-study
description: Use when learning, documenting, or debugging Linux kernel driver source code. Applies to driver study projects, object/lifecycle/callback/resource analysis, match/probe/data/IRQ/DMA paths, engineering debug notes, and embedded BusyBox/musl board bring-up.
---

# Kernel Driver Study

## Overview

Use this skill to build or maintain a structured Linux kernel driver source-learning project.
Focus on object models, lifecycle, main paths, callbacks, resource models, execution context,
user-to-kernel paths, and engineering debugging instead of isolated API memorization.

## When to Use

Use this skill when the user asks to:

- Build or maintain a Linux driver study project.
- Generate structured driver study notes.
- Analyze driver source code by objects, lifecycle, callbacks, resources, execution context, and main paths.
- Convert real driver symptoms into layered engineering debug notes.
- Update an existing driver study document.

## When Not to Use

Do not treat every Linux driver question as a document-generation task.

For ordinary learning questions:

- Answer directly.
- Do not create files.
- Do not update project notes.
- Do not update this skill.

Only update project notes when the user explicitly asks to write content into a project file.
Only update this skill when the user explicitly says a rule should become a reusable skill rule.

## Maintenance Boundary

Separate three kinds of content:

1. Ordinary learning Q&A
   - Answer directly.
   - Do not write files unless requested.

2. Project-specific study content
   - Write into the corresponding project note only when requested.
   - Examples: V4L2 object relationships, SDIO probe paths, USB enumeration details, and real board debugging logs.

3. Reusable skill rules
   - Update this skill only when the user explicitly asks to change the reusable workflow.
   - Examples: new required chapter structure, new debug template, new output rule, and new embedded constraint.

Do not store specific driver knowledge inside this skill unless it is a reusable analysis rule.

## Language Rule

Default generated project notes should be written in Chinese.

Keep code symbols, struct names, function names, file paths, and call paths in their original form.
Use English only when the user explicitly requests it or when writing code comments that must match an existing English codebase.

## Source Accuracy Rule

Do not invent source paths, function names, struct fields, or call chains.

If source code is not available in the workspace or has not been inspected, state that the source has not been checked.

When analyzing real code:

- Inspect the relevant files first.
- Cite exact file paths.
- Distinguish confirmed source facts from inferred framework behavior.

## Core Workflow

### 1. Establish project boundaries

- Determine whether the task is a bus project, subsystem project, board bring-up project, or a mixed project.
- Identify the first source entry points before expanding into detailed function analysis.
- Keep the project aligned with existing study directories and chapter numbering when a project already exists.

### 2. Build the chapter skeleton

- For a new project, create the default `00-09` chapter set described in [project-skeleton.md](references/project-skeleton.md).
- For a complex project, add optional lifecycle, relationship, callback, resource, context, and user-path chapters from the same reference.
- Keep chapter openings consistent: `本章定位`、`核心对象`、`关键函数`、`主流程`.

### 3. Build object and flow models first

- Read [object-flow-model.md](references/object-flow-model.md) before deep source walkthroughs.
- Explain core structs at field level only for the fields required to understand the current chapter.
- Build object relationship diagrams before diving into long call paths.
- Treat lifecycle, callbacks, resources, execution context, and user-to-kernel paths as first-class parts of driver understanding.

### 4. Analyze source by layer

- Place each function in the main path instead of listing calls without context.
- Distinguish direct calls from framework callbacks.
- Tie code to concrete objects, resources, and execution context.
- When the task is example-driven, map generic framework rules to a real driver file and real callback table.

### 5. Convert source analysis into engineering notes

- Write in learning-note tone only.
- Prefer structs, functions, call paths, relationship diagrams, and failure points over long pasted code.
- Keep notes suitable for later review and real debugging, not only for one-time explanation.

### 6. Use issue-driven debugging structure when symptoms appear

- Read [engineering-debug.md](references/engineering-debug.md) for layered debugging and engineering Q&A rules.
- Map each symptom to a layer, a key object, a main-path stage, and a resource or callback checkpoint.
- For embedded targets, always consider BusyBox or minimal-rootfs command alternatives.

## References

- [project-skeleton.md](references/project-skeleton.md)
  Use for project placement, `00-09` chapter skeleton, chapter templates, initialization steps, and completion criteria.
- [object-flow-model.md](references/object-flow-model.md)
  Use for source entry rules, field-level object notes, relationship diagrams, function writeups, lifecycle, callbacks, resources, context, and user-to-kernel paths.
- [engineering-debug.md](references/engineering-debug.md)
  Use for layered debugging, engineering Q&A structure, symptom-to-layer reasoning, BusyBox or musl constraints, and response templates.

## Output Rules

- Use learning-note wording inside generated project files.
- Default generated notes to Chinese unless the user requests another language.
- Do not use person-centered or conversational phrasing inside notes.
- Prefer source paths, function names, struct names, call paths, and relationship diagrams over long code blocks.
- When a task is issue-driven, always organize it as `现象 -> 层级 -> 对象 -> 主流程阶段 -> 资源/回调检查点`.
- Do not write or modify files unless the user explicitly requests file creation or maintenance.
- Do not update this skill unless the user explicitly asks to update the reusable skill rules.
