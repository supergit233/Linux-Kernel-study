---
name: kernel-driver-study
description: Structured Linux kernel driver source learning, note building, and engineering-debug workflow for platform and device tree, bus enumeration and match/probe, V4L2, USB, SDIO, MMC, PCIe, DRM, ALSA, network, IRQ, DMA, callbacks, lifecycle, resource models, and embedded board bring-up. Use when Codex needs to analyze a Linux kernel driver or subsystem, organize a driver-study project, explain object relationships and call paths, trace user-space to kernel paths, or turn real driver symptoms into layered debugging notes and engineering Q&A.
---

# Kernel Driver Study

## Overview

Use this skill to build or maintain a structured Linux kernel driver source-learning project.
Focus on object models, lifecycle, main paths, callbacks, resource models, execution context,
user-to-kernel paths, and engineering debugging instead of isolated API memorization.

## Core Workflow

### 1. Establish project boundaries

- Determine whether the task is a bus project, subsystem project, board bring-up project, or a mixed project.
- Identify the first source entry points before expanding into detailed function analysis.
- Keep the project aligned with existing study directories and chapter numbering when a project already exists.

### 2. Build the chapter skeleton

- For a new project, create the default `00-09` chapter set described in [project-skeleton.md](references/project-skeleton.md).
- For a complex project, add optional lifecycle, relationship, callback, resource, context, and user-path chapters from the same reference.
- Keep chapter openings consistent: `本章定位`、`核心对象`、`关键函数`、`主流程`.

### 3. Build object and flow models first

- Read [object-flow-model.md](references/object-flow-model.md) before deep source walkthroughs.
- Explain core structs at field level only for the fields required to understand the current chapter.
- Build object relationship diagrams before diving into long call paths.
- Treat lifecycle, callbacks, resources, execution context, and user-to-kernel paths as first-class parts of driver understanding.

### 4. Analyze source by layer

- Place each function in the main path instead of listing calls without context.
- Distinguish direct calls from framework callbacks.
- Tie code to concrete objects, resources, and execution context.
- When the task is example-driven, map generic framework rules to a real driver file and real callback table.

### 5. Convert source analysis into engineering notes

- Write in learning-note tone only.
- Prefer structs, functions, call paths, relationship diagrams, and failure points over long pasted code.
- Keep notes suitable for later review and real debugging, not only for one-time explanation.

### 6. Use issue-driven debugging structure when symptoms appear

- Read [engineering-debug.md](references/engineering-debug.md) for layered debugging and engineering Q&A rules.
- Map each symptom to a layer, a key object, a main-path stage, and a resource or callback checkpoint.
- For embedded targets, always consider BusyBox or minimal-rootfs command alternatives.

## References

- [project-skeleton.md](references/project-skeleton.md)
  Use for project placement, `00-09` chapter skeleton, chapter templates, initialization steps, and completion criteria.
- [object-flow-model.md](references/object-flow-model.md)
  Use for source entry rules, field-level object notes, relationship diagrams, function writeups, lifecycle, callbacks, resources, context, and user-to-kernel paths.
- [engineering-debug.md](references/engineering-debug.md)
  Use for layered debugging, engineering Q&A structure, symptom-to-layer reasoning, BusyBox or musl constraints, and response templates.

## Output Rules

- Use learning-note wording inside generated project files.
- Do not use person-centered or conversational phrasing inside notes.
- Prefer source paths, function names, struct names, call paths, and relationship diagrams over long code blocks.
- When a task is issue-driven, always organize it as `现象 -> 层级 -> 对象 -> 主流程阶段 -> 资源/回调检查点`.
